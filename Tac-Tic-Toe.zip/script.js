//=====================================================================
// Display Control Variables
const CANVAS_WIDTH = 600
const CANVAS_HEIGHT = 600

var GRID_SCALE = 50
var GRID_ROW_COUNT = 6
var GRID_COL_COUNT = 6
var RUN_LIMIT = 4
//Let's see if we can center the grid!
const GRID_TOP_MARGIN = (0.5*CANVAS_HEIGHT)-(0.5*GRID_ROW_COUNT*GRID_SCALE)
const GRID_LEFT_MARGIN = (0.5*CANVAS_WIDTH)-(0.5*GRID_COL_COUNT*GRID_SCALE)

const X = "red"
const O = "blue"
const BLANK = "white"



//Create a 2D array with GRID_ROW_COUNT rows, and GRID_COL_COUNT columns
var GRID_DATA = []

var X_TURN = true

var X_IS_HUMAN = true
var O_IS_HUMAN = false

var AI_NAME = "blocky"

//=====================================================================
// Functions
//---------------------------------------------------------------------

//Handle the procedures of ending one player's turn and beginning another's
function nextTurn(){
  X_TURN = !X_TURN
}

//Clears the grid data and resets the game
function resetBoard(current_board){
  for(let r=0; r< current_board.length; r+=1){
    for(let c=0; c< current_board[r].length; c+=1){
      current_board[r][c] = BLANK
    }    
  }
}

//Returns whether a given Row and Column are in the Grid
function inGrid(current_board,r,c){
  return 0<=r && r<current_board.length && 0<=c && c<current_board[r].length
}

//Returns true if the given player ID controls enough squares in a row
//example: if( playerHasWon(X) ){ doWinStuff() }
function playerHasWon(player){ 
  
  return boardHasWin(GRID_DATA,player)
}
//Calculate whether a given player has won in a given board-state.
function boardHasWin(current_board, player){
  let counter = 0
  let victory = false
  //Horizontal Victory...
  for(let r=0;r<GRID_ROW_COUNT;r+=1){ //for each row...
    counter = 0
    for(let c=0; c<GRID_COL_COUNT; c+=1){ //for each column within the row...
      if(current_board[r][c] == player){
        counter ++
      }
      else{
        counter = 0
      }
      if(counter == RUN_LIMIT){ //Check for victory criteria
        victory = true
      }
    }
  }
  //Vertical Victory...
  for(let c=0;c<GRID_COL_COUNT; c+=1){
    counter = 0
    for(let r=0;r<GRID_ROW_COUNT;r+=1){
      if(current_board[r][c] == player){
        counter ++
      }
      else{
        counter = 0
      }
      if(counter == RUN_LIMIT){ //Check for victory criteria
        victory = true
      }
    }
  }
  //Major Diagonal Victory...
  //create a for loop that counts from the smallest MD to the largest MD
  for(let D=-GRID_COL_COUNT+1; D<=GRID_ROW_COUNT-1; D+=1){
    counter = 0
    for(let r=0;r<GRID_ROW_COUNT; r+=1){
      let c = r-D
      if(0 <= c && c< GRID_COL_COUNT && current_board[r][c] == player){// Checks whether the square is out of bounds before attempting to read data that could be invalid.
        counter ++
      }
      else{
        counter = 0
      }
      if(counter == RUN_LIMIT){ //Check for victory criteria
        victory = true
      }
    }
  }
  //Minor Diagonal Victory...
  //create a for loop that counts from the smallest mD to the largest mD
  for(let d=0; d<=GRID_ROW_COUNT+GRID_COL_COUNT-2; d+=1){
    counter = 0
    for(let r=0;r<GRID_ROW_COUNT; r+=1){
      let c = d-r
      if(0 <= c && c< GRID_COL_COUNT && current_board[r][c] == player){// Checks whether the square is out of bounds before attempting to read data that could be invalid.
        counter ++
      }
      else{
        counter = 0
      }
      if(counter == RUN_LIMIT){ //Check for victory criteria
        victory = true
      }
    }
  }

  return victory
}

//Returns whether the board is full
function boardIsFull(current_board){
  found_a_blank = false
  for(let r=0;r<current_board.length;r+=1){
    for(let c=0;c<current_board[r].length;c+=1){
      if(current_board[r][c] == BLANK){
        found_a_blank = true
      }
      
    }
  }
  return !found_a_blank  
}

//Returns whether the game is a Tie
function tieGame(current_board){
  if(boardIsFull(current_board)&&!playerHasWon(X)&&!playerHasWon(O)){
    return true
  }
  else{
    return false
  }
}

//Returns whether the game is over
function gameIsOver(current_board){
  return playerHasWon(X)||playerHasWon(O)||tieGame(current_board)
}

//Get Random Item from a List
function getRandomItem(list){
  //console.log("Get a random item from:",list)
  // let random_number = Math.random()
  // let random_position = random_number*list.length
  // let random_index = Math.floor(random_position)
  // let random_item = list[random_index]
  // return random_item
  return list[Math.floor(Math.random()*list.length)]
}

//Returns whether a move is legal
function isLegalMove(current_board,r,c){  
  return inGrid(current_board,r,c) && current_board[r][c] == BLANK
}

//======================================================================
// AI Code
//----------------------------------------------------------------------
//AI function!  This function should return a legal row and column on the board to play on, given the current state of the board.
function AI_Move(current_board, current_player, opponent){
  if(AI_NAME == "random"){
    return AI_RANDOM(current_board,current_player, opponent)
  }
  if(AI_NAME == "grabby"){
    return AI_GRABBY(current_board,current_player, opponent)
  }
  if(AI_NAME == "blocky"){
    return AI_BLOCKY(current_board, current_player, opponent)
  }
  if(AI_NAME == "looky"){
    
  }
}
//---------------------------------------------------------------------
//
function getLegalMoves(current_board){
  //Given the current board, generate a list of row/column pairs that are legal moves
  let legal_moves = []
  for(let r=0; r<current_board.length; r+=1){
    for(let c=0; c<current_board[r].length; c+=1){
      if(current_board[r][c]==BLANK){
        legal_moves.push([r,c])
      }
    }
  }
  return legal_moves
}

//---------------------------------------------------------------------
//Random AI
function AI_RANDOM(current_board, current_player, opponent){
  let legal_moves = getLegalMoves(current_board)
  //console.log(legal_moves)
  return getRandomItem(legal_moves)
}
//---------------------------------------------------------------------
// Grabby AI that will take any victory it sees.
function AI_GRABBY(current_board, current_player, opponent){
  // console.log("AI_GRABBY", current_player)
  let legal_moves = getLegalMoves(current_board)
  //If there is a move that will make the player win, return that.
  for(let move of legal_moves){
    //create a copy of the board, and play the move on the copy
    // console.log("move:",move)
    let copy_of_board = current_board.map(function(row){
      return row.slice()
    })
    let [r,c] = move //create r and c from list elements
    copy_of_board[r][c] = current_player //play move
    if(boardHasWin(copy_of_board, current_player)){
      return move
    } 
  }
  //If the loop ends with no victory, return a random legal move
  return getRandomItem(legal_moves)
  
}

//---------------------------------------------------------
// Blocking AI
// This AI will block any move that will make the opponent win, and also take any move that would make IT win.
function AI_BLOCKY(current_board, current_player, opponent){
  let legal_moves = getLegalMoves(current_board)
  //Look for victories...
  for(let move of legal_moves){
    //create a copy of the board, and play the move on the copy
    let copy_of_board = current_board.map(function(row){
      return row.slice()
    })
    let [r,c] = move //create r and c from list elements
    copy_of_board[r][c] = current_player //play move
    if(boardHasWin(copy_of_board, current_player)){
      return move
    }
  }
  //Look for opponent victories...
  for(let move of legal_moves){
    //create a copy of the board, and play the move on the copy
    let copy_of_board = current_board.map(function(row){
      return row.slice()
    })
    let [r,c] = move //create r and c from list elements
    copy_of_board[r][c] = opponent //play move
    if(boardHasWin(copy_of_board, opponent)){
      return move
    }
  }
  //If the loop ends with no victory or block, return a random legal move
  return getRandomItem(legal_moves)
}

//---------------------------------------------------------------
// Looky AI
// This AI will look into the future recursively, taking victories, and blocking opponent victories as it sees them.
function AI_LOOKY(current_board, current_player, opponent){
  let legal_moves = getLegalMoves(current_board)
  //Look for victories...
  for(let move of legal_moves){
    //create a copy of the board, and play the move on the copy
    let copy_of_board = current_board.map(function(row){
      return row.slice()
    })
    let [r,c] = move //create r and c from list elements
    copy_of_board[r][c] = current_player //play move
    if(boardHasWin(copy_of_board, current_player)){
      return move
    }
  }
  //Look for opponent victories...
}

//=====================================================================
// Button Functions
//---------------------------------------------------------------------

function resetGame(){
  resetBoard(GRID_DATA)
  X_TURN = true
}

function doAIMove(){
  if(gameIsOver(GRID_DATA)==false){
    let current_player = (X_TURN ? X : O)
    let opponent = (X_TURN ? O : X)
    let move = AI_Move(GRID_DATA, current_player, opponent)
    let [r,c] = move
    GRID_DATA[r][c] = current_player
    nextTurn()
  }
}

//=====================================================================
// p5.js Functions
//---------------------------------------------------------------------

//The setup() function is called once when the program starts. 
function setup(){
  createCanvas(CANVAS_WIDTH,CANVAS_HEIGHT)
  background("gray")

  //test_button = new Button(50,50,50,50,"Test")
  //New Game Button
  reset_button = new Button(500,50,100,50,"New Game")
  reset_button.setFunction(resetGame)
  //AI Turn button
  AI_move_button = new Button(75,50,160,50,"Click for AI turn")
  AI_move_button.setFunction(doAIMove)
  //Create and fill out the 2D array
  for(let r=0;r<GRID_ROW_COUNT;r+=1){
    GRID_DATA.push([])
    for(let c=0;c<GRID_COL_COUNT;c+=1){
      GRID_DATA[r].push(BLANK)
    }
  }
  
}

//Called directly after setup(), the draw() function continuously executes the lines of code contained inside its block until the program is stopped or noLoop() is called.
function draw(){
  background("gray")

  //Draw Grid
  for(let r=0;r<GRID_ROW_COUNT;r+=1){
    for(let c=0;c<GRID_COL_COUNT;c+=1){
      fill( GRID_DATA[r][c] )
      
      let x = GRID_SCALE*c + GRID_LEFT_MARGIN
      let y = GRID_SCALE*r + GRID_TOP_MARGIN
      let w = GRID_SCALE
      let h = GRID_SCALE
      rect(x,y,w,h)
    }
  }
    
  // noLoop()

  ////Text code to demonstrate column calculations
  // let mx = mouseX - GRID_LEFT_MARGIN
  // let msc = mx/GRID_SCALE
  // let mc = Math.floor(msc)
  let X_WON = playerHasWon(X)
  let O_WON = playerHasWon(O)
  let TIE_GAME = tieGame(GRID_DATA)
  
  textSize(30)
  fill("black")
  // text(mouseX, 10, 30)
  // text(mx, 10, 60)
  // text(msc, 10, 90)
  // text(mc, 10, 120)
  let mouseRow = Math.floor((mouseY-GRID_TOP_MARGIN)/GRID_SCALE)
  let mouseCol = Math.floor((mouseX-GRID_LEFT_MARGIN)/GRID_SCALE)
  //textAlign(LEFT,BOTTOM)
  //text(`r:${mouseRow},c:${mouseCol}`, 10,30)
  //text(`X's Turn: ${X_TURN}`, 300,30)
  // text(`X Victory: ${X_WON}`,10,80)
  // text(`O Victory: ${O_WON}`,300,80)
  // text(`TIE Game: ${TIE_GAME}`,10,130)

 
  //Determine and print out the "Game Status"
  let GAME_STATUS = "error: game status not set"
  if(X_TURN){
    GAME_STATUS = "X's Turn"
  }
  if(!X_TURN){
    GAME_STATUS = "O's Turn"
  }
  if(X_WON){
    GAME_STATUS = "X has won! Congratulations!"
  }
  if(O_WON){
    GAME_STATUS = "O has won! Congratulations!"
  }
  if(TIE_GAME){
    GAME_STATUS = "Tie Game."
  }
  textAlign(CENTER,CENTER)
  text(GAME_STATUS, 300,500)

  // Process Turns
  // if(!(X_WON || O_WON || TIE_GAME)){
  //   if(X_TURN){
  //     if(X_IS_HUMAN){
  //       // Insert code to allow the user to make a move
  //     }
  //     else{
  //       // Wait for 1 second
  //       await new Promise(resolve => setTimeout(resolve, 1000));
  //       let [r,c] = AI_Move(GRID_DATA,X)
  //       GRID_DATA[r][c] = X
  //       nextTurn()
  //     }
  //   }
  //   else{
  //     if(O_IS_HUMAN){
  //       // Insert code to allow the user to make a move
  //     }
  //     else{
  //       // Wait for 1 second
  //       await new Promise(resolve => setTimeout(resolve, 1000));
  //       let [r,c] = AI_Move(GRID_DATA,O)
  //       GRID_DATA[r][c] = O
  //       nextTurn()
  //     }
  //   }
  // }

  //Draw Buttons
  //test_button.draw()
  reset_button.draw()
  AI_move_button.draw()

  //text(AI_NAME, 275,50) //Display chosen AI name

  // line(0,0,600,600)
  // ellipse(100,200,300,400)
}

function mousePressed(){
  //test_button.handleClick()
  reset_button.handleClick()
  AI_move_button.handleClick()
  //[*]When a square is clicked, its value should be changed to some horrifyingly bright color so we can't deny that a change happened.
  //mouseX, mouseY
  //[*]When you click on a square, its color should change to the color corresponding to the current player.
  //[*]Don't let the player click on squares that have already been claimed.  Clicking on a claimed square should not change it, nor should that cause the turn to end.  (Question: What does an "unclaimed" square look like?)
  //(1) Get the location where the player wishes to play
  let mouseRow = Math.floor((mouseY-GRID_TOP_MARGIN)/GRID_SCALE)
  let mouseCol = Math.floor((mouseX-GRID_LEFT_MARGIN)/GRID_SCALE)

  //Check to see whether the game is over.  If not over, accept clicks.
  //[ ] Make sure that a square of the color of whoever's turn it is is what gets played on the board (if it's a legal move)
  if(!playerHasWon(X) && !playerHasWon(O) && !boardIsFull(GRID_DATA)){
    //Set up variables for turn calculation
    let square_color = X_TURN ? X : O
    let move
    let legal_move_has_been_made = false
    
    if(isLegalMove(GRID_DATA,mouseRow,mouseCol)){
      move = [mouseRow,mouseCol]
      legal_move_has_been_made = true
    }
    if(legal_move_has_been_made){
      //(2)Make the move happen
      let [move_row,move_col] = move //unpacks move into two variables
      GRID_DATA[move_row][move_col] = square_color
      //(3)Finish the turn
      nextTurn()
    }
  }
  else{
    //Nothing!!!
  }
}